CS356-Lab-1
===========

Adam Sommer, ads46
Sean Wareham, srw22
Jonno Schmidt, jas138
Thomas Getliffe, tg72

Fixing Lab 1 to work with tester for Lab 3.

http://www.cs.duke.edu/courses/spring14/compsci356/labs/lab1/lab1.htm

Our Lab works for all real world scenarios we could test but fails some tests with the 
tester. Please take this into consideration during grading as we feel this submission
fully satisfies all needs of a reliable transmission implementation.